﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms

$root = $PSScriptRoot
$repacker = Join-Path $root 'InfBinRepacker.exe'
$patchRoot = Join-Path $root 'PatchFiles\uncompressed'
$gameInf = Join-Path $root 'data.inf'
$gameBin = Join-Path $root 'data.bin'

function Invoke-Repacker([string[]]$Arguments, [string]$LogPath) {
    & $script:Repacker @Arguments *> $LogPath
    if ($LASTEXITCODE -ne 0) {
        $tail = (Get-Content -LiteralPath $LogPath -Tail 12 -ErrorAction SilentlyContinue) -join "`r`n"
        throw "언팩/리팩 도구가 오류 코드 $LASTEXITCODE 로 종료됐습니다.`r`n$tail"
    }
}

$script:Repacker = $repacker
if (-not (Test-Path -LiteralPath $repacker) -or -not (Test-Path -LiteralPath $patchRoot)) {
    [System.Windows.Forms.MessageBox]::Show('패처 파일이 누락됐습니다. 패처를 다시 압축 해제해 실행하세요.', '패처 파일 누락') | Out-Null
    exit 1
}
if (-not (Test-Path -LiteralPath $gameInf) -or -not (Test-Path -LiteralPath $gameBin)) {
    [System.Windows.Forms.MessageBox]::Show("패처 실행 폴더에 data.inf와 data.bin을 넣어 주세요.`r`n`r`n이 도구가 사용하는 확장자는 .ini가 아니라 .inf입니다.", '게임 파일을 찾을 수 없음') | Out-Null
    exit 1
}

$backupRoot = Join-Path $root 'backup'
$backupFolder = $backupRoot
$work = Join-Path ([IO.Path]::GetTempPath()) ('GamePatcher_' + [guid]::NewGuid().ToString('N'))
$assets = Join-Path $work 'assets'
try {
    New-Item -ItemType Directory -Path $backupFolder -Force | Out-Null
    Write-Host '1/4 Backing up original files'
    Copy-Item -LiteralPath $gameInf -Destination (Join-Path $backupFolder 'data.inf')
    Copy-Item -LiteralPath $gameBin -Destination (Join-Path $backupFolder 'data.bin')

    New-Item -ItemType Directory -Path $assets -Force | Out-Null
    Copy-Item -LiteralPath $gameInf -Destination (Join-Path $work 'data.inf')
    Copy-Item -LiteralPath $gameBin -Destination (Join-Path $work 'data.bin')

    Write-Host '2/4 Unpacking game archive'
    Invoke-Repacker @('--export', '--inf-file', $gameInf, '--bin-file', $gameBin, '--output-directory', $assets) (Join-Path $work 'export.log')

    $uncompressed = Join-Path $assets 'uncompressed'
    if (-not (Test-Path -LiteralPath $uncompressed)) { throw '언팩 폴더(uncompressed)가 생성되지 않았습니다.' }
    Write-Host '3/4 Applying patch files'
    Get-ChildItem -LiteralPath $patchRoot | Copy-Item -Destination $uncompressed -Recurse -Force

    Write-Host '4/4 Repacking patched archive'
    Invoke-Repacker @('--import', '--inf-file', (Join-Path $work 'data.inf'), '--bin-file', (Join-Path $work 'data.bin'), '--output-directory', $assets) (Join-Path $work 'import.log')

    Copy-Item -LiteralPath (Join-Path $assets 'data.inf') -Destination $gameInf -Force
    Copy-Item -LiteralPath (Join-Path $assets 'data.bin') -Destination $gameBin -Force
    Remove-Item -LiteralPath $work -Recurse -Force
    Write-Host '패치 작업이 완료되었습니다.'
    exit 0
} catch {
    $message = $_.Exception.Message
    [System.Windows.Forms.MessageBox]::Show("패치에 실패했습니다.`r`n`r`n$message`r`n`r`n원본 백업: $backupFolder\data.inf 및 $backupFolder\data.bin`r`n작업 로그와 파일: $work", '패치 실패', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
    exit 1
}




