@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0PatchGame.ps1"
if errorlevel 1 (
  echo Patch failed. Original files and logs are preserved.
  pause
  exit /b 1
)
del /f /q "%~dp0InfBinRepacker.exe" "%~dp0PatchGame.ps1" 2>nul
rmdir /s /q "%~dp0PatchFiles" 2>nul
echo.
echo 패치가 완료되었습니다.
echo 패치 결과: data.inf, data.bin
echo 원본 백업: backup\data.inf, backup\data.bin
echo.
echo 아무 키나 누르면 이 창이 닫힙니다.
pause >nul
(goto) 2>nul & del /f /q "%~f0"
